<html>
    <head>
        <title>index.php</title>
</head>
<body>
    <h1>Index.php</h1>
</body>
<html>
<?php
   echo "Hello Git";

?>